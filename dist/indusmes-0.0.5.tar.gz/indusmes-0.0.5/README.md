# Description #
This is a manufacturing execution system application created by IndusWorks. This app is intended to be run on Raspberry Pi. 
