# Description #
This is a manufacturing execution system application created by IndusWorks. This app is intended to be run on Raspberry Pi. 

source /home/navneetjain89/projects/indusmes/.env/bin/activate