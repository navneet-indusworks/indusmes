# Description #
This is a manufacturing execution system application created by IndusWorks. This app is intended to be run on Raspberry Pi. 

# Steps #
Download and install /dist/indusmes-0.0.3-py3-none-any.whl